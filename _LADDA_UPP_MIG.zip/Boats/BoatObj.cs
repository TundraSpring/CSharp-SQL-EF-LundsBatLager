﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LundsBåtLager
{
    /// <summary>
    /// Parent class where pBoat and the actual boat classes converge
    /// </summary>
    internal class BoatObj
    {

    }
}
