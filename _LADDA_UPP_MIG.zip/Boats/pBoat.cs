﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LundsBåtLager
{
    /// <summary>
    /// Short for "placeholder Boat" or "pointer Boat".
    /// </summary>
    internal class pBoat : BoatObj
    {
        //This class is redundant in this project, and is kept as a proof-of-concept of how Inheritance can be used
        //in a more interesting way than the other boat classes handle it. It's purpose is to be placed in the LundsBåtLager
        //array when a boat takes up more than 1 place.
    }
}
