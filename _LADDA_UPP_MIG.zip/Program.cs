﻿namespace LundsBåtLager
{
    internal class Program
    {
        static void Main(string[] args)
        {
            LundsBåtLager lundsBåtLager = new();
            lundsBåtLager.Run();
        }
    }
}
